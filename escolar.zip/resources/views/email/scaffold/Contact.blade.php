<div class="contact">
  <p>
    Siéntete libre de contactarnos para cualquier duda o aclaración a
    <br>
    <a href="mailto:contacto@solmetec.mx" target="_blank" style="color: inherit">contacto@solmetec.mx</a>
  </p>
</div>