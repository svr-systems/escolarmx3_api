<div class="footer">
  <p>
    Este correo electrónico puede contener información confidencial, por lo que queda estrictamente prohibido el uso,
    reproducción, retransmisión o divulgación no autorizada, parcial o total, de su contenido. Si usted no es el
    destinatario del presente correo, por favor eliminelo junto con cualquier documento adjunto que pudiera contener. El
    tratamiento de los datos personales en SOLMETEC Soluciones Médicas se realiza conforme al Aviso de Privacidad que se
    encuentra disponible en la página de internet
    <br />
    <a href="https://test.svr.com.mx" style="color: inherit">solmetec.mx</a>
  </p>
</div>