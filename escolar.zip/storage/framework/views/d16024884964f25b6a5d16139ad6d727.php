<div class="contact">
  <p>
    Siéntete libre de contactarnos para cualquier duda o aclaración a
    <br>
    <a href="mailto:contacto@solmetec.mx" target="_blank" style="color: inherit">contacto@solmetec.mx</a>
  </p>
</div><?php /**PATH C:\wamp64\www\Test\escolar\resources\views/email/scaffold/Contact.blade.php ENDPATH**/ ?>