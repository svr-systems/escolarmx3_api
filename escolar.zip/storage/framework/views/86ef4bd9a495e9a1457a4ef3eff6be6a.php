

<?php $__env->startSection('content'); ?>
  <div>
    <h2 class="font-weight-light">Confirmación de cuenta</h2>
    <p class="text">
    ¡Te damos la bienvenida a MedicPay!
    <br>
    <br>
    Para confirmar tu cuenta, haz clic en el siguiente botón:
    </p>
    <p>
    <a href="<?php echo e($data->link); ?>" class="button button_success" style="color: white; text-decoration: none;">
      CONFIRMAR CUENTA
    </a>
    </p>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('email.scaffold.Main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\Test\escolar\resources\views/email/UserAccountConfirmation.blade.php ENDPATH**/ ?>