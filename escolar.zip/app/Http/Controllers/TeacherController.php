<?php

namespace App\Http\Controllers;

use App\Models\Teacher;
use App\Models\TeacherDegree;
use Illuminate\Http\Request;
use App\Models\User;
use Throwable;
use DB;

class TeacherController extends Controller
{
  public function index(Request $req) {
    try {
      return $this->apiRsp(
        200,
        'Registros retornados correctamente',
        ['items' => Teacher::getItems($req)]
      );
    } catch (Throwable $err) {
      return $this->apiRsp(500, null, $err);
    }
  }

  public function show(Request $req, $id) {
    try {
      return $this->apiRsp(
        200,
        'Registro retornado correctamente',
        ['item' => Teacher::getItem($req, $id)]
      );
    } catch (Throwable $err) {
      return $this->apiRsp(500, null, $err);
    }
  }

  public function destroy(Request $req, $id) {
    DB::beginTransaction();
    try {
      $item = Teacher::find($id);

      if (!$item) {
        return $this->apiRsp(422, 'ID no existente');
      }

      $item->active = false;
      $item->updated_by_id = $req->user()->id;
      $item->save();

      DB::commit();
      return $this->apiRsp(
        200,
        'Registro inactivado correctamente'
      );
    } catch (Throwable $err) {
      DB::rollback();
      return $this->apiRsp(500, null, $err);
    }

  }

  public function store(Request $req) {
    return $this->storeUpdate($req, null);
  }

  public function update(Request $req, $id) {
    return $this->storeUpdate($req, $id);
  }

  public function storeUpdate($req, $id) {
    DB::beginTransaction();
    try {
      $email_current = null;
      $email = GenController::filter($req->email, 'l');
      $req->role_id = 4;

      $valid = User::validEmail(['email' => $email], $id);
      if ($valid->fails()) {
        return $this->apiRsp(422, $valid->errors()->first());
      }

      $valid = User::valid($req->all());
      if ($valid->fails()) {
        return $this->apiRsp(422, $valid->errors()->first());
      }

      $store_mode = is_null($id);

      if ($store_mode) {
        $user = new User;
        $user->created_by_id = $req->user()->id;
        $user->updated_by_id = $req->user()->id;
        
        $item = new Teacher;
      } else {
        $item = Teacher::find($id);
        $user = User::find($item->user_id);
        $email_current = $user->email;

        $user->updated_by_id = $req->user()->id;
      }

      $user = UserController::saveItem($user, $req);
      $item->user_id = $user->id;
      $item->save();

      if ($req->teacher_degrees) {
        foreach ($req->teacher_degrees as $teacher_degree) {
          $teacher_degree_item = TeacherDegree::find($teacher_degree['id']);
          if (!$teacher_degree_item) {
            $teacher_degree_item = new TeacherDegree;
          }
          $teacher_degree_item->is_active = GenController::filter($teacher_degree['is_active'], 'b');
          $teacher_degree_item->level_id = GenController::filter($teacher_degree['level_id'], 'id');
          $teacher_degree_item->institution_name = GenController::filter($teacher_degree['institution_name'], 'U');
          $teacher_degree_item->name = GenController::filter($teacher_degree['name'], 'U');
          $teacher_degree_item->license_number = GenController::filter($teacher_degree['license_number'], 'U');
          $teacher_degree_item->license_url = "---";
          $teacher_degree_item->teacher_id = $item->id;
          $teacher_degree_item->save();
        }
      }

      DB::commit();
      return $this->apiRsp(
        $store_mode ? 201 : 200,
        'Registro ' . ($store_mode ? 'agregado' : 'editado') . ' correctamente',
        $store_mode ? ['item' => ['id' => $item->id]] : null
      );
    } catch (Throwable $err) {
      DB::rollback();
      return $this->apiRsp(500, null, $err);
    }
  }

  public static function saveItem($item, $data, $is_req = true) {
    
  }
}
